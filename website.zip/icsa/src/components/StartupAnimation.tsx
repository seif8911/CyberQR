import { useState, useEffect } from 'react';

interface StartupAnimationProps {
  onComplete: () => void;
}

const StartupAnimation = ({ onComplete }: StartupAnimationProps) => {
  const [showVideo, setShowVideo] = useState(true);
  const [showLoading, setShowLoading] = useState(false);
  const [showSecurityTip, setShowSecurityTip] = useState(false);
  const [currentTip, setCurrentTip] = useState(0);

  const securityTips = [
    "Always verify the sender's identity before clicking links in emails",
    "Use strong, unique passwords for each account",
    "Keep your software and apps updated regularly",
    "Enable two-factor authentication whenever possible",
    "Be cautious of unsolicited requests for personal information"
  ];

  useEffect(() => {
    // Show video for 3 seconds
    const videoTimer = setTimeout(() => {
      setShowVideo(false);
      setShowLoading(true);
    }, 3000);

    // Show security tip after loading text appears
    const tipTimer = setTimeout(() => {
      setShowSecurityTip(true);
    }, 4000);

    // Complete animation after 6 seconds total
    const completeTimer = setTimeout(() => {
      onComplete();
    }, 6000);

    return () => {
      clearTimeout(videoTimer);
      clearTimeout(tipTimer);
      clearTimeout(completeTimer);
    };
  }, [onComplete]);

  useEffect(() => {
    if (showSecurityTip) {
      const tipInterval = setInterval(() => {
        setCurrentTip((prev) => (prev + 1) % securityTips.length);
      }, 2000);
      return () => clearInterval(tipInterval);
    }
  }, [showSecurityTip, securityTips.length]);

  return (
    <div className="fixed inset-0 bg-black flex items-center justify-center z-50">
      <div className="text-center">
        {showVideo && (
          <div className="mb-8">
            <video
              autoPlay
              muted
              className="w-64 h-64 mx-auto rounded-lg shadow-2xl"
              onEnded={() => setShowVideo(false)}
            >
              <source src="/animations/mascot-1-unscreen.gif" type="video/mp4" />
              Your browser does not support the video tag.
            </video>
          </div>
        )}

        {showLoading && (
          <div className="space-y-4">
            <div className="text-2xl font-bold text-white mb-4">
              <span className="animate-pulse">Cyber QR</span>
              <span className="ml-2 animate-bounce">Loading</span>
              <span className="ml-1 animate-ping">...</span>
            </div>

            {showSecurityTip && (
              <div className="max-w-md mx-auto">
                <div className="bg-gray-800/50 backdrop-blur-sm rounded-lg p-4 border border-gray-600">
                  <h3 className="text-sm font-semibold text-cyan-400 mb-2">
                    💡 Security Tip
                  </h3>
                  <p className="text-gray-300 text-sm leading-relaxed">
                    {securityTips[currentTip]}
                  </p>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default StartupAnimation;

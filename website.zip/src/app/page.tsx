'use client';

import ResponsiveLayout from '@/components/ResponsiveLayout';

export default function Home() {
  return <ResponsiveLayout />;
}
